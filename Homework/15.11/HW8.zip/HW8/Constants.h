#pragma once
#include <stddef.h>

const size_t NUM_GRADED_ACTIVITIES = 4;
const double LOWEST_PASSING_GRADE = 60;